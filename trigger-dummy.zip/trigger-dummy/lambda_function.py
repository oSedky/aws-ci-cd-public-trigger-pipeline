def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': 'Public trigger received successfully.'
    }